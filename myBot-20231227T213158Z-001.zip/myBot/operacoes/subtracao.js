export default function subtrair (a, b) {
  return "Resultado: " + (a - b);
}
