export default function somar (a, b) {
  return "Resultado: " + (a + b);
}