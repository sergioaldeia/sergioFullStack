export default function dividir (a, b) {
  return "Resultado: " + a / b;
}