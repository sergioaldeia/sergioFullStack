export default function multiplicar (a, b) {
  return "Resultado: " + a * b;
}
