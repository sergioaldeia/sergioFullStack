export default function realizarSaudacao () {
  return "Ola, tudo bem?";
}