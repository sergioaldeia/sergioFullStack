function somar(a, b) {
  return "Resultado: " + (a + b);
}
function subtrair(a, b) {
  return "Resultado: " + (a - b);
}
function multiplicar(a, b) {
  return "Resultado: " + a * b;
}
function dividir(a, b) {
  return "Resultado: " + a / b;
}

export { somar, subtrair, multiplicar, dividir };
