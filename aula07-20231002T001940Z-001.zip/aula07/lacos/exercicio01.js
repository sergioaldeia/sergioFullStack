let numero = 20;

for(let contador = 0; contador <= 10; contador++ ) {
  console.log(numero + contador);
}

