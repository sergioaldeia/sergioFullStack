//crie uma variavel idade com a sua idade nela e exiba com o for 100 vezes ela na tela

// Exiba na tela os numeros de 1 a 20

// Exiba SOMENTE os numeros pares de 0 100


// Esse é pra casa, caso não tenham conseguido realizar