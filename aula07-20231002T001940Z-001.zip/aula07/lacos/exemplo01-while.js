let nome = "Raphael"
let verificador = "NÃO"

let contador = 1;

while( verificador === "SIM") {
  console.log(nome);
  contador++
}
