let nome = "Raphael";

for( let contador = 1; contador <= 100; contador++ ) {
  console.log(nome);
}
