let nome = "Raphael"
let numero = 200;

let contador = 1; 
do {
  console.log(nome);
  contador++;
} while (contador <= numero);
