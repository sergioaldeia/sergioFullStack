
// const [ a, b, c, d ] = ["Mesa", "Céu", "Pão", "Cadeira", "Estrada"];

const palavras = ["Mesa", "Céu", "Pão", "Cadeira", "Estrada"]
const [ a, b, c, d ] = palavras;

const [] = palavras

console.log( a, b, c, d );
