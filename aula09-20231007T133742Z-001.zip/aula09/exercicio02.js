// Crie um array de 3 a 5 filmes dentro dele

// Depois disso desestruture eles para variaveis com os nomes filme1, filme2, filme3 e filme 4