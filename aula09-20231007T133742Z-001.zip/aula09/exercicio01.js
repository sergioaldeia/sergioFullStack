// Crie um array com 5 livros e exiba eles na tela com o for of

// Agora exiba os indices destes livros