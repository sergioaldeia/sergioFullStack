const nomes = ["Maria", "João", "Carla", "Alfredo"]

nomes.push("Rapha");
nomes.push("Ricardo");
nomes.push("Ana");
nomes.pop();
nomes.pop();
nomes.pop();
nomes.unshift("Matheus");
nomes.unshift("Lilian");
nomes.shift();
nomes.shift();


console.log(nomes);
