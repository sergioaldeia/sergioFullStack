const listaFrutas = ["Banana", "Pera", "Mamao"];



listaFrutas[3] = "Uva";
listaFrutas[3] = "Manga";

console.log( listaFrutas[0] )
console.log( listaFrutas[1] )
console.log( listaFrutas[2] )
console.log( listaFrutas[3] )
