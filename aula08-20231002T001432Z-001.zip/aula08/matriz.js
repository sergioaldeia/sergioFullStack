const lista = [
  ["banana", "uva"],
  [
    "Melão", // indice 0
    "Mamão", // indice 1
    [
      "Pera", // indice 0
      "Caju", // indice 1
    ], // indice 2
  ],
];
console.log(lista[1][2][1]);
