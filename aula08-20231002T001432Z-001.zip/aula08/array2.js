const frutas = ["Banana", "Pera", "Mamao", "Mamao", "Mamao", "Mamao", "Mamao", "Mamao", "Mamao", "Mamao", "Caju", "Carambola"];

for ( let i = 0; i < frutas.length; i++) {
  let item = frutas[i]
  console.log (item);
}