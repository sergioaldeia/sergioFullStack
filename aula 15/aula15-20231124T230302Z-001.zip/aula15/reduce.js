const numeros = [2, 4, 6, 8, 10];

const total = numeros.reduce((total, el) => total * el);

console.log(total);